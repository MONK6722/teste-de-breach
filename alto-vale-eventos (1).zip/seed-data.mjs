import { drizzle } from "drizzle-orm/mysql2";
import { categories, cities } from "./drizzle/schema.ts";

const db = drizzle(process.env.DATABASE_URL);

async function seed() {
  console.log("🌱 Iniciando seed de dados...");

  try {
    // Seed categories
    const categoriesData = [
      {
        name: "Cultura",
        slug: "cultura",
        description: "Eventos culturais, exposições e apresentações artísticas",
        icon: "🎨",
        color: "#FF6B6B",
        order: 1,
      },
      {
        name: "Música",
        slug: "musica",
        description: "Shows, festivais e eventos musicais",
        icon: "🎵",
        color: "#4ECDC4",
        order: 2,
      },
      {
        name: "Teatro",
        slug: "teatro",
        description: "Peças de teatro, performances e artes cênicas",
        icon: "🎭",
        color: "#95E1D3",
        order: 3,
      },
      {
        name: "Oficina de Negócios",
        slug: "oficina-negocios",
        description: "Workshops, treinamentos e cursos de negócios",
        icon: "💼",
        color: "#F38181",
        order: 4,
      },
      {
        name: "Palestra",
        slug: "palestra",
        description: "Palestras, seminários e conferências",
        icon: "🎤",
        color: "#AA96DA",
        order: 5,
      },
    ];

    for (const cat of categoriesData) {
      await db.insert(categories).values(cat).onDuplicateKeyUpdate({ set: cat });
    }
    console.log("✅ Categorias inseridas com sucesso!");

    // Seed cities in Alto Vale region
    const citiesData = [
      {
        name: "Brusque",
        region: "Alto Vale do Itajaí",
        latitude: "-27.0867",
        longitude: "-48.9812",
      },
      {
        name: "Guabiruba",
        region: "Alto Vale do Itajaí",
        latitude: "-27.0167",
        longitude: "-48.8333",
      },
      {
        name: "Botuverá",
        region: "Alto Vale do Itajaí",
        latitude: "-27.0500",
        longitude: "-48.9500",
      },
      {
        name: "Blumenau",
        region: "Vale do Itajaí",
        latitude: "-26.8791",
        longitude: "-49.0711",
      },
      {
        name: "Gaspar",
        region: "Vale do Itajaí",
        latitude: "-26.9667",
        longitude: "-49.0667",
      },
      {
        name: "Ilhota",
        region: "Vale do Itajaí",
        latitude: "-27.2833",
        longitude: "-48.9167",
      },
      {
        name: "Pomerode",
        region: "Vale do Itajaí",
        latitude: "-26.7333",
        longitude: "-49.1667",
      },
      {
        name: "Timbó",
        region: "Vale do Itajaí",
        latitude: "-26.8333",
        longitude: "-49.3333",
      },
      {
        name: "Ascurra",
        region: "Vale do Itajaí",
        latitude: "-26.9167",
        longitude: "-49.3167",
      },
      {
        name: "Luiz Alves",
        region: "Vale do Itajaí",
        latitude: "-27.0167",
        longitude: "-49.2500",
      },
    ];

    for (const city of citiesData) {
      await db.insert(cities).values(city).onDuplicateKeyUpdate({ set: city });
    }
    console.log("✅ Cidades inseridas com sucesso!");

    console.log("🎉 Seed concluído com sucesso!");
    process.exit(0);
  } catch (error) {
    console.error("❌ Erro durante seed:", error);
    process.exit(1);
  }
}

seed();
