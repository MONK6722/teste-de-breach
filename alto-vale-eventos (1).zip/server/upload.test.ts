import { describe, it, expect, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(role: "creator" | "admin" | "user" = "creator"): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "creator-user",
    email: "creator@example.com",
    name: "Creator User",
    loginMethod: "manus",
    role,
    validatorCategories: [],
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("Photo Upload", () => {
  it("should allow creators to upload event photos", async () => {
    const ctx = createAuthContext("creator");
    const caller = appRouter.createCaller(ctx);

    const uniqueTitle = `Test Event ${Date.now()}`;
    const result = await caller.creator.submitEvent({
      title: uniqueTitle,
      description: "Test Description with enough content",
      categoryId: 1,
      cityId: 1,
      address: "Test Address",
      startDate: new Date(),
      coverImage: "https://example.com/cover.jpg",
    });

    expect(result.success).toBe(true);
    expect(result.id).toBeDefined();
  });

  it("should reject non-creators from uploading", async () => {
    const ctx = createAuthContext("user");
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.creator.submitEvent({
        title: `Test Event ${Date.now()}`,
        description: "Test Description with enough content",
        categoryId: 1,
        cityId: 1,
        address: "Test Address",
        startDate: new Date(),
      });
      expect.fail("Should have thrown error");
    } catch (error: any) {
      expect(error.message).toContain("Unauthorized");
    }
  });

  it("should validate required fields", async () => {
    const ctx = createAuthContext("creator");
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.creator.submitEvent({
        title: "A",
        description: "Test",
        categoryId: 1,
        cityId: 1,
        address: "Test Address",
        startDate: new Date(),
      });
      expect.fail("Should have thrown validation error");
    } catch (error: any) {
      expect(error.message).toBeDefined();
    }
  });
});
