import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import {
  getDb,
  getApprovedEvents,
  getFeaturedEvents,
  getEventsByCategory,
  getEventsByCity,
  searchEvents,
  getEventById,
  getEventBySlug,
  getCreatorEvents,
  getPendingEvents,
  getPastEvents,
  getEventRatings,
  getCategories,
  getCities,
  getOrdersByUser,
  getOrderById,
  getTicketsByOrder,
} from "./db";
import { events, orders, tickets, eventRatings, InsertEvent, users } from "../drizzle/schema";
import { eq, desc } from "drizzle-orm";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
    creatorLogin: publicProcedure
      .input(z.object({ email: z.string().email(), password: z.string() }))
      .mutation(async ({ input, ctx }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        const userList = await db.select().from(users).where(eq(users.email, input.email)).limit(1);
        
        if (userList.length === 0 || (userList[0].role !== 'creator' && userList[0].role !== 'admin')) {
          throw new Error("Email ou senha inválidos");
        }

        const cookieOptions = getSessionCookieOptions(ctx.req);
        ctx.res.cookie(COOKIE_NAME, userList[0].openId, { ...cookieOptions, maxAge: 7 * 24 * 60 * 60 * 1000 });

        return { success: true, user: userList[0] };
      }),
  }),

  // Public event queries
  events: router({
    getFeatured: publicProcedure.query(async () => {
      return getFeaturedEvents(6);
    }),

    getApproved: publicProcedure
      .input(z.object({ limit: z.number().default(20), offset: z.number().default(0) }))
      .query(async ({ input }) => {
        return getApprovedEvents(input.limit, input.offset);
      }),

    getByCategory: publicProcedure
      .input(z.object({ categoryId: z.number(), limit: z.number().default(20), offset: z.number().default(0) }))
      .query(async ({ input }) => {
        return getEventsByCategory(input.categoryId, input.limit, input.offset);
      }),

    getByCity: publicProcedure
      .input(z.object({ cityId: z.number(), limit: z.number().default(20), offset: z.number().default(0) }))
      .query(async ({ input }) => {
        return getEventsByCity(input.cityId, input.limit, input.offset);
      }),

    search: publicProcedure
      .input(z.object({ query: z.string(), limit: z.number().default(20), offset: z.number().default(0) }))
      .query(async ({ input }) => {
        return searchEvents(input.query, input.limit, input.offset);
      }),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const event = await getEventById(input.id);
        if (event) {
          const db = await getDb();
          if (db) {
            await db.update(events).set({ viewCount: (event.viewCount || 0) + 1 }).where(eq(events.id, input.id));
          }
        }
        return event;
      }),

    getBySlug: publicProcedure
      .input(z.object({ slug: z.string() }))
      .query(async ({ input }) => {
        return getEventBySlug(input.slug);
      }),

    getPast: publicProcedure
      .input(z.object({ limit: z.number().default(20), offset: z.number().default(0) }))
      .query(async ({ input }) => {
        return getPastEvents(input.limit, input.offset);
      }),

    getRatings: publicProcedure
      .input(z.object({ eventId: z.number() }))
      .query(async ({ input }) => {
        return getEventRatings(input.eventId);
      }),

    addRating: protectedProcedure
      .input(z.object({ eventId: z.number(), rating: z.number().min(1).max(5), comment: z.string().optional() }))
      .mutation(async ({ input, ctx }) => {
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        await db.insert(eventRatings).values({
          eventId: input.eventId,
          userId: ctx.user.id,
          rating: input.rating,
          comment: input.comment,
        });

        return { success: true };
      }),
  }),

  // Metadata queries
  metadata: router({
    getCategories: publicProcedure.query(async () => {
      return getCategories();
    }),

    getCities: publicProcedure.query(async () => {
      return getCities();
    }),
  }),

  // Creator procedures
  creator: router({
    getMyEvents: protectedProcedure.query(async ({ ctx }) => {
      return getCreatorEvents(ctx.user.id);
    }),

    submitEvent: protectedProcedure
      .input(z.object({
        title: z.string().min(3),
        description: z.string().min(10),
        categoryId: z.number(),
        subcategoryId: z.number().optional(),
        cityId: z.number(),
        address: z.string(),
        latitude: z.number().optional(),
        longitude: z.number().optional(),
        startDate: z.date(),
        endDate: z.date().optional(),
        startTime: z.string().optional(),
        capacity: z.number().optional(),
        coverImage: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user.role !== 'creator' && ctx.user.role !== 'admin') {
          throw new Error("Unauthorized: Only creators can submit events");
        }
        const db = await getDb();
        if (!db) throw new Error("Database not available");

        const slug = input.title.toLowerCase().replace(/\s+/g, '-').replace(/[^\w-]/g, '');

        const result = await db.insert(events).values({
          creatorId: ctx.user.id,
          title: input.title,
          slug,
          description: input.description,
          categoryId: input.categoryId,
          subcategoryId: input.subcategoryId,
          cityId: input.cityId,
          address: input.address,
          latitude: input.latitude ? String(input.latitude) as any : undefined,
          longitude: input.longitude ? String(input.longitude) as any : undefined,
          startDate: input.startDate,
          endDate: input.endDate,
          startTime: input.startTime,
          capacity: input.capacity,
          coverImage: input.coverImage,
          status: 'pending',
        });

        return { id: result[0].insertId, success: true };
      }),
  }),

  // Admin procedures
  admin: router({
    getPendingEvents: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== 'admin' && ctx.user.role !== 'validator') {
        throw new Error("Unauthorized");
      }
      return getPendingEvents();
    }),

    approveEvent: protectedProcedure
      .input(z.object({ eventId: z.number(), verified: z.boolean().optional() }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user.role !== 'admin' && ctx.user.role !== 'validator') {
          throw new Error("Unauthorized");
        }

        const db = await getDb();
        if (!db) throw new Error("Database not available");

        await db.update(events)
          .set({
            status: 'approved',
            validatorId: ctx.user.id,
            verified: input.verified || false,
          })
          .where(eq(events.id, input.eventId));

        return { success: true };
      }),

    rejectEvent: protectedProcedure
      .input(z.object({ eventId: z.number(), reason: z.string() }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user.role !== 'admin' && ctx.user.role !== 'validator') {
          throw new Error("Unauthorized");
        }

        const db = await getDb();
        if (!db) throw new Error("Database not available");

        await db.update(events)
          .set({
            status: 'rejected',
            rejectionReason: input.reason,
            validatorId: ctx.user.id,
          })
          .where(eq(events.id, input.eventId));

        return { success: true };
      }),
  }),

  // Orders and tickets
  orders: router({
    getMyOrders: protectedProcedure.query(async ({ ctx }) => {
      return getOrdersByUser(ctx.user.id);
    }),

    getOrder: protectedProcedure
      .input(z.object({ orderId: z.number() }))
      .query(async ({ input, ctx }) => {
        const order = await getOrderById(input.orderId);
        if (!order || order.userId !== ctx.user.id) {
          throw new Error("Order not found");
        }
        return order;
      }),

    getOrderTickets: protectedProcedure
      .input(z.object({ orderId: z.number() }))
      .query(async ({ input, ctx }) => {
        const order = await getOrderById(input.orderId);
        if (!order || order.userId !== ctx.user.id) {
          throw new Error("Order not found");
        }
        return getTicketsByOrder(input.orderId);
      }),
  }),
});

export type AppRouter = typeof appRouter;
