import { describe, it, expect } from "vitest";

describe("Checkout and Sharing", () => {
  it("should calculate correct total with service fee", () => {
    const ticketPrice = 50.00;
    const serviceFee = 3.50;
    const quantity = 2;

    const subtotal = ticketPrice * quantity;
    const totalFee = serviceFee * quantity;
    const total = subtotal + totalFee;

    expect(subtotal).toBe(100.00);
    expect(totalFee).toBe(7.00);
    expect(total).toBe(107.00);
  });

  it("should handle free tickets correctly", () => {
    const ticketPrice = 0;
    const serviceFee = 0; // Free tickets have no fee
    const quantity = 5;

    const subtotal = ticketPrice * quantity;
    const totalFee = serviceFee * quantity;
    const total = subtotal + totalFee;

    expect(subtotal).toBe(0);
    expect(totalFee).toBe(0);
    expect(total).toBe(0);
  });

  it("should validate share URLs", () => {
    const eventSlug = "teste-evento";
    const baseUrl = "https://example.com";
    const shareUrl = `${baseUrl}/event/${eventSlug}`;

    expect(shareUrl).toContain("/event/");
    expect(shareUrl).toContain(eventSlug);
  });

  it("should format WhatsApp message correctly", () => {
    const eventTitle = "Teste Evento";
    const eventUrl = "https://example.com/event/teste";
    const message = `Confira este evento: ${eventTitle}\n${eventUrl}`;

    expect(message).toContain(eventTitle);
    expect(message).toContain(eventUrl);
  });
});
