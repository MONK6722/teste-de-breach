import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import EventDetail from "./pages/EventDetail";
import CreateEvent from "./pages/CreateEvent";
import AdminPanel from "./pages/AdminPanel";
import Cart from "./pages/Cart";
import PastEvents from "./pages/PastEvents";
import UserProfile from "./pages/UserProfile";
import SearchEvents from "./pages/SearchEvents";
import CreatorLogin from "./pages/CreatorLogin";
import Checkout from "./pages/Checkout";
import Feedback from "./pages/Feedback";
import ValidatorPanel from "./pages/ValidatorPanel";
import FreeTickets from "./pages/FreeTickets";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/event/:slug" component={EventDetail} />
      <Route path="/criar-evento" component={CreateEvent} />
      <Route path="/admin" component={AdminPanel} />
      <Route path="/carrinho" component={Cart} />
      <Route path="/eventos-passados" component={PastEvents} />
      <Route path="/perfil" component={UserProfile} />
      <Route path="/buscar" component={SearchEvents} />
      <Route path="/criador-login" component={CreatorLogin} />
      <Route path="/checkout" component={Checkout} />
      <Route path="/feedback" component={Feedback} />
      <Route path="/validador" component={ValidatorPanel} />
      <Route path="/ingressos-gratis" component={FreeTickets} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
