import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { QrCode, Download, CheckCircle, AlertCircle } from "lucide-react";

export default function FreeTickets() {
  const [selectedTicket, setSelectedTicket] = useState<number | null>(null);

  // Mock data
  const freeTickets = [
    {
      id: 1,
      eventTitle: "Workshop Gratuito de Web Design",
      eventDate: "2026-05-15",
      eventTime: "14:00",
      ticketCode: "FREE-WEB-001",
      qrCode: "https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=FREE-WEB-001",
      capacity: 50,
      reserved: 32,
      status: "active",
    },
    {
      id: 2,
      eventTitle: "Palestra sobre Empreendedorismo",
      eventDate: "2026-05-20",
      eventTime: "19:00",
      ticketCode: "FREE-EMP-001",
      qrCode: "https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=FREE-EMP-001",
      capacity: 100,
      reserved: 78,
      status: "active",
    },
  ];

  const handleDownloadQR = (ticket: any) => {
    // Simular download do QR code
    const link = document.createElement("a");
    link.href = ticket.qrCode;
    link.download = `qr-${ticket.ticketCode}.png`;
    link.click();
  };

  const handleReserveTicket = (ticketId: number) => {
    // Simular reserva de ingresso
    alert("Ingresso reservado com sucesso! Verifique seu email.");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/5 px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <QrCode className="w-8 h-8 text-primary" />
            <h1 className="text-4xl font-bold text-foreground">Ingressos Gratuitos</h1>
          </div>
          <p className="text-muted-foreground">
            Reserve seu ingresso gratuito e receba o QR code para check-in
          </p>
        </div>

        <div className="grid gap-6">
          {freeTickets.map((ticket) => (
            <Card key={ticket.id} className="card-elegant p-6">
              <div className="grid md:grid-cols-3 gap-6">
                {/* Informações do Evento */}
                <div className="md:col-span-2">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h2 className="text-2xl font-semibold text-foreground mb-2">
                        {ticket.eventTitle}
                      </h2>
                      <div className="flex gap-2 flex-wrap mb-4">
                        <Badge variant="outline">
                          📅 {new Date(ticket.eventDate).toLocaleDateString("pt-BR")}
                        </Badge>
                        <Badge variant="outline">
                          🕐 {ticket.eventTime}
                        </Badge>
                        <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
                          ✓ Gratuito
                        </Badge>
                      </div>
                    </div>
                  </div>

                  {/* Capacidade */}
                  <div className="mb-4">
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-muted-foreground">Lugares Disponíveis:</span>
                      <span className="font-medium text-foreground">
                        {ticket.capacity - ticket.reserved} de {ticket.capacity}
                      </span>
                    </div>
                    <div className="w-full bg-muted rounded-full h-2">
                      <div
                        className="bg-primary rounded-full h-2 transition-all"
                        style={{
                          width: `${(ticket.reserved / ticket.capacity) * 100}%`,
                        }}
                      />
                    </div>
                  </div>

                  {/* Botão de Reserva */}
                  <Button
                    onClick={() => handleReserveTicket(ticket.id)}
                    className="bg-primary hover:bg-primary/90 gap-2"
                  >
                    <CheckCircle className="w-4 h-4" />
                    Reservar Ingresso Gratuito
                  </Button>
                </div>

                {/* QR Code */}
                <div className="flex flex-col items-center justify-center p-4 bg-accent/5 rounded-lg">
                  <img
                    src={ticket.qrCode}
                    alt={`QR Code ${ticket.ticketCode}`}
                    className="w-32 h-32 mb-3"
                  />
                  <p className="text-xs text-muted-foreground text-center mb-3">
                    {ticket.ticketCode}
                  </p>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDownloadQR(ticket)}
                    className="gap-2 w-full"
                  >
                    <Download className="w-4 h-4" />
                    Baixar QR
                  </Button>
                </div>
              </div>

              {/* Informações Adicionais */}
              {selectedTicket === ticket.id && (
                <div className="mt-6 pt-6 border-t border-border">
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex gap-3">
                    <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-blue-800">
                      <p className="font-medium mb-1">Como funciona:</p>
                      <ul className="list-disc list-inside space-y-1">
                        <li>Reserve seu ingresso gratuito aqui</li>
                        <li>Você receberá um QR code por email</li>
                        <li>Apresente o QR code no dia do evento</li>
                        <li>Nossos validadores farão o check-in</li>
                      </ul>
                    </div>
                  </div>
                </div>
              )}
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
