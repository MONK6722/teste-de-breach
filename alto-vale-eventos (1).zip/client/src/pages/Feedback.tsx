import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Star, Send, CheckCircle } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function Feedback() {
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [message, setMessage] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = async () => {
    if (rating === 0) {
      toast.error("Por favor, selecione uma avaliação");
      return;
    }

    if (message.trim().length < 10) {
      toast.error("Por favor, escreva uma mensagem com pelo menos 10 caracteres");
      return;
    }

    try {
      // Aqui você faria a chamada para salvar o feedback
      // await trpc.feedback.submit.useMutation();
      setSubmitted(true);
      setTimeout(() => {
        setRating(0);
        setMessage("");
        setSubmitted(false);
      }, 3000);
      toast.success("Obrigado pelo seu feedback!");
    } catch (error) {
      toast.error("Erro ao enviar feedback");
    }
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/5 flex items-center justify-center px-4 py-8">
        <Card className="card-elegant p-8 max-w-md text-center">
          <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="w-8 h-8 text-green-600" />
          </div>
          <h1 className="text-2xl font-bold text-foreground mb-2">
            Obrigado!
          </h1>
          <p className="text-muted-foreground">
            Seu feedback foi recebido com sucesso. Vamos usar suas sugestões para melhorar!
          </p>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/5 px-4 py-12">
      <div className="max-w-2xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-2">
            Sua Opinião Importa
          </h1>
          <p className="text-lg text-muted-foreground">
            Nos ajude a melhorar a plataforma Alto Vale Eventos
          </p>
        </div>

        <Card className="card-elegant p-8">
          <div className="mb-8">
            <label className="block text-lg font-semibold text-foreground mb-4">
              Como você avalia nossa plataforma?
            </label>
            <div className="flex gap-4 justify-center">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  onClick={() => setRating(star)}
                  onMouseEnter={() => setHoverRating(star)}
                  onMouseLeave={() => setHoverRating(0)}
                  className="transition-transform hover:scale-110"
                >
                  <Star
                    className={`w-12 h-12 transition-colors ${
                      star <= (hoverRating || rating)
                        ? "fill-yellow-400 text-yellow-400"
                        : "text-muted-foreground"
                    }`}
                  />
                </button>
              ))}
            </div>
            <div className="text-center mt-2 text-sm text-muted-foreground">
              {rating > 0 && (
                <span>
                  {rating === 1 && "Muito ruim"}
                  {rating === 2 && "Ruim"}
                  {rating === 3 && "Bom"}
                  {rating === 4 && "Muito bom"}
                  {rating === 5 && "Excelente"}
                </span>
              )}
            </div>
          </div>

          <div className="mb-6">
            <label className="block text-lg font-semibold text-foreground mb-3">
              Deixe seu comentário
            </label>
            <Textarea
              placeholder="Conte-nos o que você achou... (mínimo 10 caracteres)"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="min-h-32 resize-none"
            />
            <div className="text-sm text-muted-foreground mt-1">
              {message.length} caracteres
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <Button
              variant="outline"
              onClick={() => {
                setRating(0);
                setMessage("");
              }}
            >
              Limpar
            </Button>
            <Button
              onClick={handleSubmit}
              className="bg-primary hover:bg-primary/90 gap-2"
            >
              <Send className="w-4 h-4" />
              Enviar Feedback
            </Button>
          </div>

          <div className="mt-6 p-4 bg-accent/10 border border-accent/20 rounded-lg">
            <p className="text-sm text-muted-foreground">
              📧 Você também pode entrar em contato conosco em:{" "}
              <a
                href="mailto:ilab.corporation.oficial@gmail.com"
                className="text-primary hover:underline font-medium"
              >
                ilab.corporation.oficial@gmail.com
              </a>
            </p>
          </div>
        </Card>
      </div>
    </div>
  );
}
