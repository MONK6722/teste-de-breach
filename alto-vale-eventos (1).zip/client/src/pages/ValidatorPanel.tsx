import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, XCircle, Clock, Shield, Loader } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function ValidatorPanel() {
  const [selectedEvent, setSelectedEvent] = useState<number | null>(null);
  const [rejectionReason, setRejectionReason] = useState("");
  const [approvingId, setApprovingId] = useState<number | null>(null);
  const [rejectingId, setRejectingId] = useState<number | null>(null);

  // Buscar eventos pendentes do backend
  const { data: pendingEvents = [], isLoading } = trpc.admin.getPendingEvents.useQuery();
  const approveMutation = trpc.admin.approveEvent.useMutation();
  const rejectMutation = trpc.admin.rejectEvent.useMutation();

  // Mock data - em produção, viria do servidor
  const mockPendingEvents = [
    {
      id: 1,
      title: "Workshop de Web Design",
      category: "Oficina de Negócios",
      creator: "João Silva",
      status: "pending",
      createdAt: new Date(),
      description: "Workshop prático sobre web design moderno",
    },
    {
      id: 2,
      title: "Show de Música ao Vivo",
      category: "Música",
      creator: "Maria Santos",
      status: "pending",
      createdAt: new Date(),
      description: "Show com banda local de rock",
    },
  ];

  const handleApprove = async (eventId: number) => {
    setApprovingId(eventId);
    try {
      await approveMutation.mutateAsync({ eventId, verified: true });
      toast.success("Evento aprovado com sucesso!");
      setSelectedEvent(null);
    } catch (error) {
      toast.error("Erro ao aprovar evento");
    } finally {
      setApprovingId(null);
    }
  };

  const handleReject = async (eventId: number) => {
    if (!rejectionReason.trim()) {
      toast.error("Por favor, informe o motivo da rejeição");
      return;
    }

    setRejectingId(eventId);
    try {
      await rejectMutation.mutateAsync({ eventId, reason: rejectionReason });
      toast.success("Evento rejeitado");
      setSelectedEvent(null);
      setRejectionReason("");
    } catch (error) {
      toast.error("Erro ao rejeitar evento");
    } finally {
      setRejectingId(null);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/5 flex items-center justify-center">
        <Loader className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  const eventsToDisplay = (pendingEvents && pendingEvents.length > 0) ? pendingEvents : mockPendingEvents;

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/5 px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Shield className="w-8 h-8 text-primary" />
            <h1 className="text-4xl font-bold text-foreground">Painel de Validação</h1>
          </div>
          <p className="text-muted-foreground">
            Revise e valide eventos da sua categoria
          </p>
        </div>

        <div className="grid gap-6">
          {eventsToDisplay.map((event) => (
            <Card
              key={event.id}
              className="card-elegant p-6 cursor-pointer hover:shadow-lg transition"
              onClick={() => setSelectedEvent(event.id)}
            >
              <div className="flex justify-between items-start mb-4">
                  <div>
                    <h2 className="text-xl font-semibold text-foreground mb-2">
                      {event.title}
                    </h2>
                    <div className="flex gap-2 flex-wrap">
                      <Badge variant="outline">Evento</Badge>
                      <Badge variant="secondary">
                        <Clock className="w-3 h-3 mr-1" />
                        Pendente
                      </Badge>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-muted-foreground">Criador:</p>
                    <p className="font-medium text-foreground">{(event as any).creator || "Criador"}</p>
                  </div>
              </div>

              <p className="text-muted-foreground mb-4">{event.description}</p>

              {selectedEvent === event.id && (
                  <div className="mt-6 pt-6 border-t border-border space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-2">
                        Motivo da Rejeição (se aplicável)
                      </label>
                      <textarea
                        value={rejectionReason}
                        onChange={(e) => setRejectionReason(e.target.value)}
                        placeholder="Explique por que o evento está sendo rejeitado..."
                        className="w-full p-3 border border-border rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-primary"
                        rows={3}
                      />
                    </div>

                    <div className="flex gap-3">
                      <Button
                        onClick={() => handleApprove(event.id)}
                        disabled={approvingId === event.id || rejectingId === event.id}
                        className="flex-1 gap-2 bg-green-600 hover:bg-green-700"
                      >
                        {approvingId === event.id ? (
                          <Loader className="w-4 h-4 animate-spin" />
                        ) : (
                          <CheckCircle2 className="w-4 h-4" />
                        )}
                        {approvingId === event.id ? "Aprovando..." : "Aprovar"}
                      </Button>
                      <Button
                        onClick={() => handleReject(event.id)}
                        disabled={approvingId === event.id || rejectingId === event.id}
                        variant="destructive"
                        className="flex-1 gap-2"
                      >
                        {rejectingId === event.id ? (
                          <Loader className="w-4 h-4 animate-spin" />
                        ) : (
                          <XCircle className="w-4 h-4" />
                        )}
                        {rejectingId === event.id ? "Rejeitando..." : "Rejeitar"}
                      </Button>
                    </div>
                  </div>
              )}
            </Card>
          ))}
        </div>

        {eventsToDisplay.length === 0 && (
          <Card className="card-elegant p-12 text-center">
            <CheckCircle2 className="w-16 h-16 text-green-600 mx-auto mb-4" />
            <h2 className="text-2xl font-semibold text-foreground mb-2">
              Tudo em Dia!
            </h2>
            <p className="text-muted-foreground">
              Não há eventos pendentes para validação neste momento.
            </p>
          </Card>
        )}
      </div>
    </div>
  );
}
