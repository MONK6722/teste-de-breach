import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2, ChevronLeft, Trash2 } from "lucide-react";
import { useState } from "react";

interface CartItem {
  eventId: number;
  eventTitle: string;
  ticketType: string;
  quantity: number;
  price: number;
  isFree: boolean;
}

const SERVICE_FEE_PER_TICKET = 3.50;

export default function Cart() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [cartItems, setCartItems] = useState<CartItem[]>([
    {
      eventId: 1,
      eventTitle: "Workshop de Web Design",
      ticketType: "Ingresso Padrão",
      quantity: 2,
      price: 50,
      isFree: false,
    },
  ]);

  if (!user) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center">
        <h2 className="text-2xl font-bold text-foreground mb-4">Faça login para continuar</h2>
        <Button onClick={() => setLocation("/")} variant="outline">
          Voltar para Home
        </Button>
      </div>
    );
  }

  const calculateSubtotal = () => {
    return cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  };

  const calculateServiceFee = () => {
    return cartItems.reduce((sum, item) => {
      if (item.isFree) return sum;
      return sum + (SERVICE_FEE_PER_TICKET * item.quantity);
    }, 0);
  };

  const calculateTotal = () => {
    return calculateSubtotal() + calculateServiceFee();
  };

  const handleRemoveItem = (eventId: number) => {
    setCartItems(cartItems.filter(item => item.eventId !== eventId));
  };

  const handleQuantityChange = (eventId: number, newQuantity: number) => {
    if (newQuantity <= 0) {
      handleRemoveItem(eventId);
      return;
    }
    setCartItems(cartItems.map(item =>
      item.eventId === eventId ? { ...item, quantity: newQuantity } : item
    ));
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-white dark:bg-card border-b border-border shadow-sm">
        <div className="container flex items-center justify-between h-16">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setLocation("/")}
            className="gap-2"
          >
            <ChevronLeft className="w-4 h-4" />
            Voltar
          </Button>
          <h1 className="text-lg font-bold text-foreground">Carrinho de Compras</h1>
          <div className="w-12" />
        </div>
      </header>

      <div className="container py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2">
            {cartItems.length > 0 ? (
              <div className="space-y-4">
                {cartItems.map((item) => (
                  <Card key={item.eventId} className="card-elegant p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <h3 className="font-bold text-foreground mb-1">
                          {item.eventTitle}
                        </h3>
                        <p className="text-sm text-muted-foreground">
                          {item.ticketType}
                        </p>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleRemoveItem(item.eventId)}
                        className="text-destructive hover:text-destructive"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>

                    <div className="grid grid-cols-3 gap-4 items-center">
                      <div>
                        <p className="text-sm text-muted-foreground mb-2">Quantidade</p>
                        <div className="flex items-center border border-border rounded-lg">
                          <button
                            onClick={() => handleQuantityChange(item.eventId, item.quantity - 1)}
                            className="px-3 py-2 hover:bg-muted transition"
                          >
                            −
                          </button>
                          <span className="px-4 py-2 border-l border-r border-border">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => handleQuantityChange(item.eventId, item.quantity + 1)}
                            className="px-3 py-2 hover:bg-muted transition"
                          >
                            +
                          </button>
                        </div>
                      </div>

                      <div>
                        <p className="text-sm text-muted-foreground mb-2">Preço Unitário</p>
                        <p className="font-bold text-foreground">
                          {item.isFree ? "Grátis" : `R$ ${item.price.toFixed(2)}`}
                        </p>
                      </div>

                      <div>
                        <p className="text-sm text-muted-foreground mb-2">Subtotal</p>
                        <p className="font-bold text-foreground">
                          {item.isFree ? "Grátis" : `R$ ${(item.price * item.quantity).toFixed(2)}`}
                        </p>
                      </div>
                    </div>

                    {!item.isFree && (
                      <div className="mt-4 pt-4 border-t border-border">
                        <p className="text-xs text-muted-foreground">
                          Taxa de serviço: R$ {(SERVICE_FEE_PER_TICKET * item.quantity).toFixed(2)}
                        </p>
                      </div>
                    )}
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="card-elegant p-12 text-center">
                <p className="text-muted-foreground mb-4">Seu carrinho está vazio.</p>
                <Button onClick={() => setLocation("/")} variant="outline">
                  Continuar Comprando
                </Button>
              </Card>
            )}
          </div>

          {/* Order Summary */}
          {cartItems.length > 0 && (
            <div className="lg:col-span-1">
              <Card className="card-elegant p-6 sticky top-24">
                <h3 className="text-xl font-bold text-foreground mb-6">Resumo do Pedido</h3>

                <div className="space-y-3 mb-6">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Subtotal:</span>
                    <span className="font-medium">R$ {calculateSubtotal().toFixed(2)}</span>
                  </div>

                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Taxa de Serviço:</span>
                    <span className="font-medium">R$ {calculateServiceFee().toFixed(2)}</span>
                  </div>

                  <div className="border-t border-border pt-3 flex justify-between">
                    <span className="font-bold text-foreground">Total:</span>
                    <span className="text-2xl font-bold text-primary">
                      R$ {calculateTotal().toFixed(2)}
                    </span>
                  </div>
                </div>

                <div className="space-y-3 mb-6 p-4 bg-accent/10 rounded-lg">
                  <p className="text-xs text-muted-foreground">
                    <strong>Informação sobre Taxa:</strong> A taxa de R$ 3,50 por ingresso cobre os custos de processamento e manutenção da plataforma.
                  </p>
                </div>

                <Button className="w-full bg-primary hover:bg-primary/90 h-12 mb-3">
                  Prosseguir para Checkout
                </Button>

                <Button variant="outline" className="w-full" onClick={() => setLocation("/")}>
                  Continuar Comprando
                </Button>
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
