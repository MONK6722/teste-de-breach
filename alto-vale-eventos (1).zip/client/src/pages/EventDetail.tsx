import { useParams, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2, MapPin, Calendar, Users, Star, Share2, ChevronLeft, ChevronRight, MessageCircle } from "lucide-react";
import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { MapView } from "@/components/Map";

export default function EventDetail() {
  const { slug } = useParams<{ slug?: string }>();
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const [currentPhotoIndex, setCurrentPhotoIndex] = useState(0);
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState("");

  const { data: event, isLoading } = trpc.events.getBySlug.useQuery({ slug: (slug as string) || "" });
  const { data: ratings } = trpc.events.getRatings.useQuery({ eventId: event?.id ?? 0 }, { enabled: !!event?.id });
  const addRatingMutation = trpc.events.addRating.useMutation();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!event) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center">
        <h2 className="text-2xl font-bold text-foreground mb-4">Evento não encontrado</h2>
        <Button onClick={() => setLocation("/")} variant="outline">
          Voltar para Home
        </Button>
      </div>
    );
  }

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: event.title,
          text: event.description || "",
          url: window.location.href,
        });
      } catch (err) {
        console.error("Error sharing:", err);
      }
    } else {
      // Fallback: copy to clipboard
      navigator.clipboard.writeText(window.location.href);
      alert("Link copiado para a área de transferência!");
    }
  };

  const handleAddRating = async () => {
    if (rating === 0) {
      alert("Por favor, selecione uma classificação");
      return;
    }
    try {
      await addRatingMutation.mutateAsync({
        eventId: event.id,
        rating,
        comment: comment || undefined,
      });
      setRating(0);
      setComment("");
      alert("Avaliação adicionada com sucesso!");
    } catch (error) {
      alert("Erro ao adicionar avaliação");
    }
  };

  const averageRating = ratings?.length
    ? (ratings.reduce((sum, r) => sum + r.rating, 0) / ratings.length).toFixed(1)
    : "0";

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-white dark:bg-card border-b border-border shadow-sm">
        <div className="container flex items-center justify-between h-16">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setLocation("/")}
            className="gap-2"
          >
            <ChevronLeft className="w-4 h-4" />
            Voltar
          </Button>
          <h1 className="text-lg font-bold text-foreground flex-1 text-center line-clamp-1">
            {event.title}
          </h1>
          <Button
            variant="ghost"
            size="sm"
            onClick={handleShare}
            className="gap-2"
          >
            <Share2 className="w-4 h-4" />
            Compartilhar
          </Button>
        </div>
      </header>

      {/* Photo Carousel */}
      {event.coverImage && (
        <div className="relative w-full h-96 bg-muted overflow-hidden">
          <img
            src={event.coverImage}
            alt={event.title}
            className="w-full h-full object-cover"
          />
          {event.verified && (
            <div className="absolute top-4 right-4 badge-verified">
              ✓ Verificado
            </div>
          )}
          <button
            onClick={() => setCurrentPhotoIndex(Math.max(0, currentPhotoIndex - 1))}
            className="absolute left-4 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-2 rounded-full transition"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <button
            onClick={() => setCurrentPhotoIndex(currentPhotoIndex + 1)}
            className="absolute right-4 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-2 rounded-full transition"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        </div>
      )}

      <div className="container py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Event Info */}
            <Card className="card-elegant p-6 mb-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h2 className="text-3xl font-bold text-foreground mb-2">
                    {event.title}
                  </h2>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 fill-accent text-accent" />
                      {averageRating} ({ratings?.length || 0} avaliações)
                    </div>
                    {event.viewCount && (
                      <div>{event.viewCount} visualizações</div>
                    )}
                  </div>
                </div>
              </div>

              <div className="space-y-4 mb-6">
                <div className="flex items-start gap-3">
                  <Calendar className="w-5 h-5 text-primary flex-shrink-0 mt-1" />
                  <div>
                    <p className="font-medium text-foreground">Data e Hora</p>
                    <p className="text-muted-foreground">
                      {new Date(event.startDate).toLocaleDateString('pt-BR', {
                        weekday: 'long',
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric',
                      })}
                      {event.startTime && ` às ${event.startTime}`}
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-primary flex-shrink-0 mt-1" />
                  <div>
                    <p className="font-medium text-foreground">Localização</p>
                    <p className="text-muted-foreground">{event.address}</p>
                  </div>
                </div>

                {event.capacity && (
                  <div className="flex items-start gap-3">
                    <Users className="w-5 h-5 text-primary flex-shrink-0 mt-1" />
                    <div>
                      <p className="font-medium text-foreground">Capacidade</p>
                      <p className="text-muted-foreground">{event.capacity} pessoas</p>
                    </div>
                  </div>
                )}
              </div>
            </Card>

            {/* Description */}
            <Card className="card-elegant p-6 mb-6">
              <h3 className="text-xl font-bold text-foreground mb-4">Sobre o Evento</h3>
              <p className="text-muted-foreground whitespace-pre-wrap">
                {event.description}
              </p>
            </Card>

            {/* Map */}
            {event.latitude && event.longitude && (
              <Card className="card-elegant p-6 mb-6">
                <h3 className="text-xl font-bold text-foreground mb-4">Localização no Mapa</h3>
                <div className="h-96 rounded-lg overflow-hidden">
                  <MapView
                    initialCenter={{
                      lat: parseFloat(event.latitude?.toString() || "0"),
                      lng: parseFloat(event.longitude?.toString() || "0"),
                    }}
                    initialZoom={15}
                  />
                </div>
              </Card>
            )}

            {/* Ratings */}
            <Card className="card-elegant p-6">
              <h3 className="text-xl font-bold text-foreground mb-6">Avaliações</h3>

              {user && (
                <div className="mb-8 pb-8 border-b border-border">
                  <p className="font-medium text-foreground mb-4">Deixe sua avaliação</p>
                  <div className="flex gap-2 mb-4">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        onClick={() => setRating(star)}
                        className="text-3xl transition hover:scale-110"
                      >
                        <Star
                          className={`w-8 h-8 ${
                            star <= rating
                              ? "fill-accent text-accent"
                              : "text-muted"
                          }`}
                        />
                      </button>
                    ))}
                  </div>
                  <textarea
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    placeholder="Compartilhe sua experiência (opcional)"
                    className="w-full p-3 border border-border rounded-lg mb-4 resize-none"
                    rows={3}
                  />
                  <Button
                    onClick={handleAddRating}
                    disabled={addRatingMutation.isPending}
                    className="w-full"
                  >
                    {addRatingMutation.isPending ? "Enviando..." : "Enviar Avaliação"}
                  </Button>
                </div>
              )}

              <div className="space-y-4">
                {ratings && ratings.length > 0 ? (
                  ratings.map((r) => (
                    <div key={r.id} className="pb-4 border-b border-border last:border-0">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="flex gap-1">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`w-4 h-4 ${
                                i < r.rating
                                  ? "fill-accent text-accent"
                                  : "text-muted"
                              }`}
                            />
                          ))}
                        </div>
                        <span className="text-sm text-muted-foreground">
                          {new Date(r.createdAt).toLocaleDateString('pt-BR')}
                        </span>
                      </div>
                      {r.comment && (
                        <p className="text-muted-foreground text-sm">{r.comment}</p>
                      )}
                    </div>
                  ))
                ) : (
                  <p className="text-muted-foreground text-center py-8">
                    Nenhuma avaliação ainda. Seja o primeiro a avaliar!
                  </p>
                )}
              </div>
            </Card>
          </div>

          {/* Sidebar - Tickets */}
          <div className="lg:col-span-1">
            <Card className="card-elegant p-6 sticky top-24">
              <h3 className="text-xl font-bold text-foreground mb-6">Ingressos</h3>
              <div className="space-y-4">
                <div className="p-4 bg-primary/10 rounded-lg">
                  <p className="text-sm text-muted-foreground mb-1">Tipo de Ingresso</p>
                  <p className="text-2xl font-bold text-primary">Ingresso Padrão</p>
                  <p className="text-sm text-muted-foreground mt-2">R$ 50,00</p>
                </div>

                <div className="p-4 bg-accent/10 rounded-lg">
                  <p className="text-sm text-muted-foreground mb-1">Taxa de Serviço</p>
                  <p className="text-lg font-bold text-accent">R$ 3,50 por ingresso</p>
                </div>

                <div className="flex items-center gap-2 mb-4">
                  <input
                    type="number"
                    min="1"
                    max="10"
                    defaultValue="1"
                    className="flex-1 px-3 py-2 border border-border rounded-lg"
                  />
                  <span className="text-sm text-muted-foreground">ingressos</span>
                </div>

                <div className="space-y-2 p-4 bg-muted/30 rounded-lg">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Subtotal:</span>
                    <span className="font-medium">R$ 50,00</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Taxa:</span>
                    <span className="font-medium">R$ 3,50</span>
                  </div>
                  <div className="border-t border-border pt-2 flex justify-between">
                    <span className="font-bold">Total:</span>
                    <span className="font-bold text-primary">R$ 53,50</span>
                  </div>
                </div>

                <Button className="w-full bg-primary hover:bg-primary/90 h-12">
                  Comprar Ingressos
                </Button>

                <Button variant="outline" className="w-full">
                  Adicionar ao Carrinho
                </Button>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
