import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2, ChevronLeft, LogOut, Ticket } from "lucide-react";
import { trpc } from "@/lib/trpc";

export default function UserProfile() {
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();
  const { data: userTickets, isLoading } = trpc.orders.getMyOrders.useQuery();
  const logoutMutation = trpc.auth.logout.useMutation();

  if (!user) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center">
        <h2 className="text-2xl font-bold text-foreground mb-4">Faça login para continuar</h2>
        <Button onClick={() => setLocation("/")} variant="outline">
          Voltar para Home
        </Button>
      </div>
    );
  }

  const handleLogout = async () => {
    try {
      await logoutMutation.mutateAsync();
      logout();
      setLocation("/");
    } catch (error) {
      alert("Erro ao fazer logout");
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-white dark:bg-card border-b border-border shadow-sm">
        <div className="container flex items-center justify-between h-16">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setLocation("/")}
            className="gap-2"
          >
            <ChevronLeft className="w-4 h-4" />
            Voltar
          </Button>
          <h1 className="text-lg font-bold text-foreground">Meu Perfil</h1>
          <div className="w-12" />
        </div>
      </header>

      <div className="container py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Profile Info */}
          <div className="lg:col-span-1">
            <Card className="card-elegant p-6">
              <div className="text-center mb-6">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center mx-auto mb-4">
                  <span className="text-white text-2xl font-bold">
                    {user.name?.charAt(0).toUpperCase() || "U"}
                  </span>
                </div>
                <h2 className="text-xl font-bold text-foreground">{user.name}</h2>
                <p className="text-sm text-muted-foreground">{user.email}</p>
              </div>

              <div className="space-y-2 mb-6 pb-6 border-b border-border">
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Tipo de Conta:</span>
                  <span className="text-sm font-medium text-foreground capitalize">
                    {user.role === "creator" ? "Criador de Eventos" : "Participante"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Membro desde:</span>
                  <span className="text-sm font-medium text-foreground">
                    {new Date(user.createdAt).toLocaleDateString("pt-BR")}
                  </span>
                </div>
              </div>

              {user.role === "creator" && (
                <Button
                  className="w-full bg-primary hover:bg-primary/90 mb-2"
                  onClick={() => setLocation("/criar-evento")}
                >
                  Criar Novo Evento
                </Button>
              )}

              <Button
                variant="destructive"
                className="w-full gap-2"
                onClick={handleLogout}
                disabled={logoutMutation.isPending}
              >
                <LogOut className="w-4 h-4" />
                {logoutMutation.isPending ? "Saindo..." : "Fazer Logout"}
              </Button>
            </Card>
          </div>

          {/* Tickets and History */}
          <div className="lg:col-span-2">
            <Card className="card-elegant p-6">
              <div className="flex items-center gap-2 mb-6">
                <Ticket className="w-5 h-5 text-primary" />
                <h3 className="text-xl font-bold text-foreground">Meus Ingressos</h3>
              </div>

              {isLoading ? (
                <div className="flex justify-center py-12">
                  <Loader2 className="w-8 h-8 animate-spin text-primary" />
                </div>
              ) : userTickets && userTickets.length > 0 ? (
                <div className="space-y-4">
                  {userTickets.map((ticket: any) => (
                    <div
                      key={ticket.id}
                      className="p-4 border border-border rounded-lg hover:border-primary transition"
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h4 className="font-bold text-foreground">{ticket.eventTitle}</h4>
                          <p className="text-sm text-muted-foreground">
                            Ingresso #{ticket.ticketNumber}
                          </p>
                        </div>
                        <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                          ticket.used
                            ? "bg-green-500/10 text-green-700 dark:text-green-400"
                            : "bg-blue-500/10 text-blue-700 dark:text-blue-400"
                        }`}>
                          {ticket.used ? "Utilizado" : "Válido"}
                        </span>
                      </div>

                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <p className="text-muted-foreground mb-1">Data do Evento</p>
                          <p className="font-medium text-foreground">
                            {new Date(ticket.eventDate).toLocaleDateString("pt-BR")}
                          </p>
                        </div>
                        <div>
                          <p className="text-muted-foreground mb-1">Local</p>
                          <p className="font-medium text-foreground line-clamp-1">
                            {ticket.eventLocation}
                          </p>
                        </div>
                      </div>

                      <Button
                        size="sm"
                        variant="outline"
                        className="w-full mt-3"
                        onClick={() => setLocation(`/event/${ticket.eventSlug}`)}
                      >
                        Ver Evento
                      </Button>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <p className="text-muted-foreground mb-4">Você ainda não comprou nenhum ingresso.</p>
                  <Button
                    onClick={() => setLocation("/")}
                    className="bg-primary hover:bg-primary/90"
                  >
                    Explorar Eventos
                  </Button>
                </div>
              )}
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
