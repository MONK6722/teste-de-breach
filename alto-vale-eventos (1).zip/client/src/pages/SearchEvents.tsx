import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2, ChevronLeft, MapPin, Calendar, Star, Search } from "lucide-react";
import { useLocation } from "wouter";
import { useState } from "react";

export default function SearchEvents() {
  const [, setLocation] = useLocation();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
  const [selectedCity, setSelectedCity] = useState<number | null>(null);
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");

  const { data: categories } = trpc.metadata.getCategories.useQuery();
  const { data: cities } = trpc.metadata.getCities.useQuery();
  const { data: searchResults, isLoading } = trpc.events.search.useQuery({
    query: searchTerm || "",
    limit: 20,
    offset: 0,
  });

  const handleReset = () => {
    setSearchTerm("");
    setSelectedCategory(null);
    setSelectedCity(null);
    setStartDate("");
    setEndDate("");
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-white dark:bg-card border-b border-border shadow-sm">
        <div className="container flex items-center justify-between h-16">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setLocation("/")}
            className="gap-2"
          >
            <ChevronLeft className="w-4 h-4" />
            Voltar
          </Button>
          <h1 className="text-lg font-bold text-foreground">Buscar Eventos</h1>
          <div className="w-12" />
        </div>
      </header>

      <div className="container py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Filters Sidebar */}
          <div className="lg:col-span-1">
            <Card className="card-elegant p-6 sticky top-24">
              <h3 className="text-lg font-bold text-foreground mb-6">Filtros</h3>

              {/* Search */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-foreground mb-2">
                  Buscar por Nome
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Nome do evento..."
                    className="w-full px-3 py-2 pl-10 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                  />
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                </div>
              </div>

              {/* Note: Filtros adicionais podem ser implementados no backend */}

              <Button
                variant="outline"
                className="w-full"
                onClick={handleReset}
              >
                Limpar Filtros
              </Button>
            </Card>
          </div>

          {/* Results */}
          <div className="lg:col-span-3">
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-foreground">
                Resultados da Busca
              </h2>
              <p className="text-muted-foreground mt-1">
                {searchResults?.length || 0} evento(s) encontrado(s)
              </p>
            </div>

            {isLoading ? (
              <div className="flex justify-center py-12">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
              </div>
            ) : searchResults && searchResults.length > 0 ? (
              <div className="space-y-4">
                {searchResults.map((event) => (
                  <Card
                    key={event.id}
                    className="card-elegant p-6 cursor-pointer hover-lift"
                    onClick={() => setLocation(`/event/${event.slug}`)}
                  >
                    <div className="flex gap-6">
                      {event.coverImage && (
                        <div className="hidden md:block w-32 h-32 rounded-lg overflow-hidden bg-muted flex-shrink-0">
                          <img
                            src={event.coverImage}
                            alt={event.title}
                            className="w-full h-full object-cover"
                          />
                        </div>
                      )}
                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-2">
                          <h3 className="text-lg font-bold text-foreground line-clamp-2">
                            {event.title}
                          </h3>
                          {event.verified && (
                            <span className="badge-verified ml-2 flex-shrink-0">
                              ✓ Verificado
                            </span>
                          )}
                        </div>

                        <p className="text-muted-foreground text-sm mb-3 line-clamp-2">
                          {event.description}
                        </p>

                        <div className="space-y-2 text-sm text-muted-foreground">
                          <div className="flex items-center gap-2">
                            <Calendar className="w-4 h-4" />
                            {new Date(event.startDate).toLocaleDateString('pt-BR')}
                            {event.startTime && ` às ${event.startTime}`}
                          </div>
                          <div className="flex items-center gap-2">
                            <MapPin className="w-4 h-4" />
                            {event.address}
                          </div>
                          {event.averageRating && (
                            <div className="flex items-center gap-2">
                              <Star className="w-4 h-4 fill-accent text-accent" />
                              {parseFloat(event.averageRating.toString()).toFixed(1)}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="card-elegant p-12 text-center">
                <p className="text-muted-foreground mb-4">
                  Nenhum evento encontrado com esses critérios.
                </p>
                <Button onClick={handleReset} variant="outline">
                  Limpar Filtros
                </Button>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
