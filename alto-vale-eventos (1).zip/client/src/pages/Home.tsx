import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2, MapPin, Calendar, Users, Star, Share2, ChevronRight } from "lucide-react";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { useLocation } from "wouter";

export default function Home() {
  const { user, loading, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
  const [selectedCity, setSelectedCity] = useState<number | null>(null);

  // Queries
  const { data: featured, isLoading: featuredLoading } = trpc.events.getFeatured.useQuery();
  const { data: approved } = trpc.events.getApproved.useQuery({ limit: 12, offset: 0 });
  const { data: categories } = trpc.metadata.getCategories.useQuery();
  const { data: cities } = trpc.metadata.getCities.useQuery();

  const filteredEvents = selectedCategory
    ? approved?.filter(e => e.categoryId === selectedCategory)
    : selectedCity
    ? approved?.filter(e => e.cityId === selectedCity)
    : approved;

  const handleEventClick = (slug: string) => {
    setLocation(`/event/${slug}`);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white dark:bg-card border-b border-border shadow-sm">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
              <span className="text-white font-bold text-lg">AV</span>
            </div>
            <h1 className="text-xl font-bold text-foreground">Alto Vale Eventos</h1>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <a href="#" className="text-sm font-medium text-foreground hover:text-primary transition">
              Eventos
            </a>
            <a href="#" className="text-sm font-medium text-foreground hover:text-primary transition">
              Categorias
            </a>
            <a href="#" className="text-sm font-medium text-foreground hover:text-primary transition">
              Sobre
            </a>
          </nav>
          <div className="flex items-center gap-3">
            {isAuthenticated ? (
              <div className="flex items-center gap-3">
                <span className="text-sm text-muted-foreground">{user?.name}</span>
                <Button variant="outline" size="sm">
                  Minha Conta
                </Button>
              </div>
            ) : (
              <Button asChild size="sm">
                <a href={getLoginUrl()}>Entrar</a>
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="hero-section bg-gradient-to-r from-primary/10 to-secondary/10 border-b border-border">
        <div className="container">
          <div className="max-w-3xl">
            <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
              Descubra Eventos Incríveis
            </h2>
            <p className="text-lg text-muted-foreground mb-8">
              Encontre os melhores eventos, workshops, palestras e muito mais na região do Alto Vale. Tudo em um só lugar.
            </p>
            <div className="flex flex-col sm:flex-row gap-3">
              <Button size="lg" className="bg-primary hover:bg-primary/90">
                Explorar Eventos
              </Button>
              {isAuthenticated && user?.role === 'creator' && (
                <Button size="lg" variant="outline" onClick={() => setLocation('/criar-evento')}>
                  Criar Evento
                </Button>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Featured Events */}
      <section className="section-padding border-b border-border">
        <div className="container">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h3 className="text-3xl font-bold text-foreground">Destaques</h3>
              <p className="text-muted-foreground mt-2">Os eventos mais procurados agora</p>
            </div>
            <Button variant="ghost" className="gap-2">
              Ver Todos <ChevronRight className="w-4 h-4" />
            </Button>
          </div>

          {featuredLoading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featured?.map((event) => (
                <Card
                  key={event.id}
                  className="card-elegant overflow-hidden cursor-pointer hover-lift"
                  onClick={() => handleEventClick(event.slug)}
                >
                  {event.coverImage && (
                    <div className="relative h-48 overflow-hidden bg-muted">
                      <img
                        src={event.coverImage}
                        alt={event.title}
                        className="w-full h-full object-cover"
                      />
                      {event.verified && (
                        <div className="absolute top-3 right-3 badge-verified">
                          ✓ Verificado
                        </div>
                      )}
                    </div>
                  )}
                  <div className="p-4">
                    <h4 className="font-bold text-foreground line-clamp-2 mb-2">
                      {event.title}
                    </h4>
                    <div className="space-y-2 text-sm text-muted-foreground">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4" />
                        {new Date(event.startDate).toLocaleDateString('pt-BR')}
                      </div>
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4" />
                        <span className="line-clamp-1">{event.address}</span>
                      </div>
                      {event.averageRating && (
                        <div className="flex items-center gap-2">
                          <Star className="w-4 h-4 fill-accent text-accent" />
                          {parseFloat(event.averageRating.toString()).toFixed(1)}
                        </div>
                      )}
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Categories */}
      <section className="section-padding border-b border-border">
        <div className="container">
          <div className="mb-8">
            <h3 className="text-3xl font-bold text-foreground">Categorias</h3>
            <p className="text-muted-foreground mt-2">Explore eventos por categoria</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {categories?.map((category) => (
              <button
                key={category.id}
                onClick={() => {
                  setSelectedCategory(selectedCategory === category.id ? null : category.id);
                  setSelectedCity(null);
                }}
                className={`p-4 rounded-lg border-2 transition-all text-center ${
                  selectedCategory === category.id
                    ? 'border-primary bg-primary/10'
                    : 'border-border hover:border-primary'
                }`}
              >
                <div className="text-2xl mb-2">{category.icon || '🎭'}</div>
                <p className="font-medium text-sm text-foreground">{category.name}</p>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Cities Filter */}
      <section className="section-padding border-b border-border">
        <div className="container">
          <div className="mb-8">
            <h3 className="text-3xl font-bold text-foreground">Cidades</h3>
            <p className="text-muted-foreground mt-2">Eventos na região do Alto Vale</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
            {cities?.map((city) => (
              <button
                key={city.id}
                onClick={() => {
                  setSelectedCity(selectedCity === city.id ? null : city.id);
                  setSelectedCategory(null);
                }}
                className={`p-3 rounded-lg border transition-all text-center ${
                  selectedCity === city.id
                    ? 'border-primary bg-primary/10 text-primary'
                    : 'border-border hover:border-primary text-foreground'
                }`}
              >
                <p className="font-medium text-sm">{city.name}</p>
                {city.region && <p className="text-xs text-muted-foreground">{city.region}</p>}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* All Events */}
      <section className="section-padding">
        <div className="container">
          <div className="mb-8">
            <h3 className="text-3xl font-bold text-foreground">
              {selectedCategory || selectedCity ? 'Eventos Filtrados' : 'Todos os Eventos'}
            </h3>
            <p className="text-muted-foreground mt-2">
              {filteredEvents?.length || 0} eventos encontrados
            </p>
          </div>

          {filteredEvents && filteredEvents.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredEvents.map((event) => (
                <Card
                  key={event.id}
                  className="card-elegant overflow-hidden cursor-pointer hover-lift"
                  onClick={() => handleEventClick(event.slug)}
                >
                  {event.coverImage && (
                    <div className="relative h-48 overflow-hidden bg-muted">
                      <img
                        src={event.coverImage}
                        alt={event.title}
                        className="w-full h-full object-cover"
                      />
                      {event.verified && (
                        <div className="absolute top-3 right-3 badge-verified">
                          ✓ Verificado
                        </div>
                      )}
                    </div>
                  )}
                  <div className="p-4">
                    <h4 className="font-bold text-foreground line-clamp-2 mb-2">
                      {event.title}
                    </h4>
                    <div className="space-y-2 text-sm text-muted-foreground">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4" />
                        {new Date(event.startDate).toLocaleDateString('pt-BR')}
                      </div>
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4" />
                        <span className="line-clamp-1">{event.address}</span>
                      </div>
                      {event.averageRating && (
                        <div className="flex items-center gap-2">
                          <Star className="w-4 h-4 fill-accent text-accent" />
                          {parseFloat(event.averageRating.toString()).toFixed(1)}
                        </div>
                      )}
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-muted-foreground mb-4">Nenhum evento encontrado com esses filtros.</p>
              <Button
                variant="outline"
                onClick={() => {
                  setSelectedCategory(null);
                  setSelectedCity(null);
                }}
              >
                Limpar Filtros
              </Button>
            </div>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-12">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-bold text-foreground mb-4">Alto Vale Eventos</h4>
              <p className="text-sm text-muted-foreground">
                A plataforma oficial de eventos da região do Alto Vale.
              </p>
            </div>
            <div>
              <h5 className="font-bold text-foreground mb-4">Navegação</h5>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="text-muted-foreground hover:text-primary">Eventos</a></li>
                <li><a href="#" className="text-muted-foreground hover:text-primary">Categorias</a></li>
                <li><a href="#" className="text-muted-foreground hover:text-primary">Sobre</a></li>
              </ul>
            </div>
            <div>
              <h5 className="font-bold text-foreground mb-4">Suporte</h5>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="text-muted-foreground hover:text-primary">Contato</a></li>
                <li><a href="#" className="text-muted-foreground hover:text-primary">FAQ</a></li>
                <li><a href="#" className="text-muted-foreground hover:text-primary">Termos</a></li>
              </ul>
            </div>
            <div>
              <h5 className="font-bold text-foreground mb-4">Redes Sociais</h5>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="text-muted-foreground hover:text-primary">Instagram</a></li>
                <li><a href="#" className="text-muted-foreground hover:text-primary">Facebook</a></li>
                <li><a href="#" className="text-muted-foreground hover:text-primary">Twitter</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2026 Alto Vale Eventos. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
