import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2, ChevronLeft, Star } from "lucide-react";
import { useLocation } from "wouter";
import { useState } from "react";

export default function PastEvents() {
  const [, setLocation] = useLocation();
  const { data: pastEvents, isLoading } = trpc.events.getPast.useQuery({ limit: 20, offset: 0 });
  const [selectedEvent, setSelectedEvent] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-white dark:bg-card border-b border-border shadow-sm">
        <div className="container flex items-center justify-between h-16">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setLocation("/")}
            className="gap-2"
          >
            <ChevronLeft className="w-4 h-4" />
            Voltar
          </Button>
          <h1 className="text-lg font-bold text-foreground">Eventos Passados</h1>
          <div className="w-12" />
        </div>
      </header>

      <div className="container py-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-foreground mb-2">Reviva os Melhores Momentos</h2>
          <p className="text-muted-foreground">
            Confira os eventos que já aconteceram e suas avaliações
          </p>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : pastEvents && pastEvents.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {pastEvents.map((event) => (
              <Card
                key={event.id}
                className="card-elegant overflow-hidden cursor-pointer hover-lift"
                onClick={() => setSelectedEvent(selectedEvent === event.id ? null : event.id)}
              >
                {event.coverImage && (
                  <div className="relative h-48 overflow-hidden bg-muted">
                    <img
                      src={event.coverImage}
                      alt={event.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute top-3 right-3 bg-black/70 text-white px-3 py-1 rounded-full text-sm font-medium">
                      Evento Passado
                    </div>
                  </div>
                )}

                <div className="p-4">
                  <h3 className="font-bold text-foreground line-clamp-2 mb-3">
                    {event.title}
                  </h3>

                  {/* Ratings */}
                  {event.averageRating && (
                    <div className="flex items-center gap-2 mb-4 p-3 bg-accent/10 rounded-lg">
                      <div className="flex gap-1">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-4 h-4 ${
                              i < Math.round(parseFloat(event.averageRating?.toString() || "0"))
                                ? "fill-accent text-accent"
                                : "text-muted"
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-sm font-medium text-foreground">
                        {parseFloat(event.averageRating.toString()).toFixed(1)}
                      </span>
                    </div>
                  )}

                  {selectedEvent === event.id && (
                    <div className="mt-4 pt-4 border-t border-border">
                      <p className="text-sm text-muted-foreground mb-3">
                        {event.description}
                      </p>
                      <Button
                        size="sm"
                        className="w-full bg-primary hover:bg-primary/90"
                        onClick={(e) => {
                          e.stopPropagation();
                          setLocation(`/event/${event.slug}`);
                        }}
                      >
                        Ver Detalhes
                      </Button>
                    </div>
                  )}
                </div>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="card-elegant p-12 text-center">
            <p className="text-muted-foreground mb-4">Nenhum evento passado encontrado.</p>
            <Button onClick={() => setLocation("/")} variant="outline">
              Voltar para Home
            </Button>
          </Card>
        )}
      </div>
    </div>
  );
}
