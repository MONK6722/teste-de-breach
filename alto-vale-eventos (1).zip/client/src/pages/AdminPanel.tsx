import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { Loader2, ChevronLeft, Check, X, Eye } from "lucide-react";

export default function AdminPanel() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [selectedEvent, setSelectedEvent] = useState<number | null>(null);
  const [rejectionReason, setRejectionReason] = useState("");

  const { data: pendingEvents, isLoading, refetch } = trpc.admin.getPendingEvents.useQuery();
  const approveEventMutation = trpc.admin.approveEvent.useMutation();
  const rejectEventMutation = trpc.admin.rejectEvent.useMutation();

  if (!user || (user.role !== "admin" && user.role !== "validator")) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center">
        <h2 className="text-2xl font-bold text-foreground mb-4">Acesso Negado</h2>
        <p className="text-muted-foreground mb-6">Apenas administradores podem acessar esta página.</p>
        <Button onClick={() => setLocation("/")} variant="outline">
          Voltar para Home
        </Button>
      </div>
    );
  }

  const handleApprove = async (eventId: number) => {
    try {
      await approveEventMutation.mutateAsync({
        eventId,
        verified: user.role === "admin",
      });
      alert("Evento aprovado com sucesso!");
      refetch();
    } catch (error) {
      alert("Erro ao aprovar evento");
    }
  };

  const handleReject = async (eventId: number) => {
    if (!rejectionReason.trim()) {
      alert("Por favor, forneça um motivo para a rejeição");
      return;
    }

    try {
      await rejectEventMutation.mutateAsync({
        eventId,
        reason: rejectionReason,
      });
      alert("Evento rejeitado com sucesso!");
      setRejectionReason("");
      setSelectedEvent(null);
      refetch();
    } catch (error) {
      alert("Erro ao rejeitar evento");
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-white dark:bg-card border-b border-border shadow-sm">
        <div className="container flex items-center justify-between h-16">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setLocation("/")}
            className="gap-2"
          >
            <ChevronLeft className="w-4 h-4" />
            Voltar
          </Button>
          <h1 className="text-lg font-bold text-foreground">Painel Administrativo</h1>
          <div className="w-12" />
        </div>
      </header>

      <div className="container py-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-foreground mb-2">Validação de Eventos</h2>
          <p className="text-muted-foreground">
            {pendingEvents?.length || 0} evento(s) aguardando aprovação
          </p>
        </div>

        {isLoading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : pendingEvents && pendingEvents.length > 0 ? (
          <div className="space-y-4">
            {pendingEvents.map((event) => (
              <Card key={event.id} className="card-elegant p-6">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Título</p>
                    <p className="font-bold text-foreground line-clamp-2">{event.title}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Data</p>
                    <p className="font-medium text-foreground">
                      {new Date(event.startDate).toLocaleDateString('pt-BR')}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Criador</p>
                    <p className="font-medium text-foreground">ID: {event.creatorId}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Status</p>
                    <p className="font-medium text-yellow-600 dark:text-yellow-400">Pendente</p>
                  </div>
                </div>

                <div className="mb-4 pb-4 border-t border-border">
                  <p className="text-sm text-muted-foreground mb-2">Descrição</p>
                  <p className="text-foreground line-clamp-3">{event.description}</p>
                </div>

                {selectedEvent === event.id ? (
                  <div className="mb-4 p-4 bg-destructive/10 rounded-lg">
                    <p className="text-sm font-medium text-foreground mb-2">Motivo da Rejeição</p>
                    <textarea
                      value={rejectionReason}
                      onChange={(e) => setRejectionReason(e.target.value)}
                      placeholder="Explique por que este evento está sendo rejeitado..."
                      className="w-full p-3 border border-border rounded-lg mb-3 resize-none"
                      rows={3}
                    />
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setSelectedEvent(null);
                          setRejectionReason("");
                        }}
                      >
                        Cancelar
                      </Button>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => handleReject(event.id)}
                        disabled={rejectEventMutation.isPending}
                      >
                        {rejectEventMutation.isPending ? "Rejeitando..." : "Confirmar Rejeição"}
                      </Button>
                    </div>
                  </div>
                ) : null}

                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="gap-2"
                    onClick={() => setLocation(`/event/${event.slug}`)}
                  >
                    <Eye className="w-4 h-4" />
                    Visualizar
                  </Button>
                  <Button
                    size="sm"
                    className="gap-2 bg-green-600 hover:bg-green-700"
                    onClick={() => handleApprove(event.id)}
                    disabled={approveEventMutation.isPending}
                  >
                    <Check className="w-4 h-4" />
                    {approveEventMutation.isPending ? "Aprovando..." : "Aprovar"}
                  </Button>
                  <Button
                    variant="destructive"
                    size="sm"
                    className="gap-2"
                    onClick={() => setSelectedEvent(event.id)}
                    disabled={selectedEvent === event.id}
                  >
                    <X className="w-4 h-4" />
                    Rejeitar
                  </Button>
                </div>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="card-elegant p-12 text-center">
            <p className="text-muted-foreground mb-4">Nenhum evento pendente de aprovação.</p>
            <Button onClick={() => setLocation("/")} variant="outline">
              Voltar para Home
            </Button>
          </Card>
        )}
      </div>
    </div>
  );
}
