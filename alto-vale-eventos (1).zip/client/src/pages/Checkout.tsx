import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, Loader2, Check } from "lucide-react";
import { trpc } from "@/lib/trpc";

const SERVICE_FEE_PER_TICKET = 3.50; // R$3,50 por ingresso

export default function Checkout() {
  const [, setLocation] = useLocation();
  const [quantity, setQuantity] = useState(1);
  const [isProcessing, setIsProcessing] = useState(false);
  const [success, setSuccess] = useState(false);

  // Mock event data - in production, get from URL params or context
  const eventId = 1;
  const ticketPrice = 50.00; // R$50,00 por ingresso
  const eventTitle = "Evento de Exemplo";

  const totalTicketPrice = ticketPrice * quantity;
  const totalServiceFee = SERVICE_FEE_PER_TICKET * quantity;
  const totalPrice = totalTicketPrice + totalServiceFee;

  const handleCheckout = async () => {
    setIsProcessing(true);
    try {
      // Simular processamento de pagamento
      await new Promise(resolve => setTimeout(resolve, 2000));
      setSuccess(true);
      setTimeout(() => setLocation("/perfil"), 2000);
    } catch (error) {
      console.error("Erro no checkout:", error);
    } finally {
      setIsProcessing(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/5 flex items-center justify-center px-4 py-8">
        <Card className="card-elegant p-8 max-w-md text-center">
          <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-4">
            <Check className="w-8 h-8 text-green-600" />
          </div>
          <h1 className="text-2xl font-bold text-foreground mb-2">
            Compra Realizada!
          </h1>
          <p className="text-muted-foreground mb-4">
            Seus ingressos foram enviados para seu email.
          </p>
          <Button
            onClick={() => setLocation("/perfil")}
            className="w-full bg-primary hover:bg-primary/90"
          >
            Ver Meus Ingressos
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/5 px-4 py-8">
      <Button
        variant="ghost"
        size="sm"
        onClick={() => setLocation("/carrinho")}
        className="gap-2 mb-6"
      >
        <ArrowLeft className="w-4 h-4" />
        Voltar
      </Button>

      <div className="max-w-2xl mx-auto">
        <h1 className="text-3xl font-bold text-foreground mb-8">Checkout</h1>

        <div className="grid gap-6 md:grid-cols-3">
          {/* Resumo do Evento */}
          <div className="md:col-span-2">
            <Card className="card-elegant p-6 mb-6">
              <h2 className="text-xl font-semibold text-foreground mb-4">
                Resumo do Evento
              </h2>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Evento:</span>
                  <span className="font-medium text-foreground">{eventTitle}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Quantidade:</span>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="px-3 py-1 border border-border rounded hover:bg-accent/50 transition"
                    >
                      −
                    </button>
                    <span className="w-8 text-center font-medium">{quantity}</span>
                    <button
                      onClick={() => setQuantity(quantity + 1)}
                      className="px-3 py-1 border border-border rounded hover:bg-accent/50 transition"
                    >
                      +
                    </button>
                  </div>
                </div>
              </div>
            </Card>

            {/* Detalhes de Preço */}
            <Card className="card-elegant p-6">
              <h2 className="text-xl font-semibold text-foreground mb-4">
                Detalhes do Pagamento
              </h2>
              <div className="space-y-3 border-b border-border pb-4 mb-4">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">
                    Ingresso (R${ticketPrice.toFixed(2)}) × {quantity}
                  </span>
                  <span className="font-medium text-foreground">
                    R${totalTicketPrice.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">
                    Taxa do site (R${SERVICE_FEE_PER_TICKET.toFixed(2)}) × {quantity}
                  </span>
                  <span className="font-medium text-foreground">
                    R${totalServiceFee.toFixed(2)}
                  </span>
                </div>
              </div>

              <div className="flex justify-between items-center mb-6">
                <span className="text-lg font-semibold text-foreground">
                  Total:
                </span>
                <span className="text-2xl font-bold text-primary">
                  R${totalPrice.toFixed(2)}
                </span>
              </div>

              <div className="bg-accent/10 border border-accent/20 rounded-lg p-4 mb-6">
                <p className="text-sm text-muted-foreground">
                  💡 <strong>Transparência:</strong> A taxa de R${SERVICE_FEE_PER_TICKET.toFixed(2)} por ingresso cobre custos de processamento e manutenção da plataforma.
                </p>
              </div>

              <Button
                onClick={handleCheckout}
                disabled={isProcessing}
                className="w-full bg-primary hover:bg-primary/90 h-12 text-lg"
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Processando...
                  </>
                ) : (
                  `Pagar R$${totalPrice.toFixed(2)}`
                )}
              </Button>

              <p className="text-xs text-muted-foreground text-center mt-4">
                Seus dados estão seguros. Processamento seguro de pagamento.
              </p>
            </Card>
          </div>

          {/* Resumo Lateral */}
          <div>
            <Card className="card-elegant p-6 sticky top-6">
              <h3 className="font-semibold text-foreground mb-4">Resumo</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Ingressos:</span>
                  <span className="font-medium">{quantity}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Subtotal:</span>
                  <span className="font-medium">R${totalTicketPrice.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Taxa:</span>
                  <span className="font-medium">R${totalServiceFee.toFixed(2)}</span>
                </div>
                <div className="border-t border-border pt-2 mt-2">
                  <div className="flex justify-between font-semibold">
                    <span>Total:</span>
                    <span className="text-primary">R${totalPrice.toFixed(2)}</span>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
