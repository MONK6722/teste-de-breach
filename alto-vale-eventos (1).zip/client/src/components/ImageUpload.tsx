import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Upload, X, AlertCircle, Check } from "lucide-react";

interface ImageUploadProps {
  onUpload: (file: File, preview: string) => void;
  maxSize?: number; // em MB
  accept?: string;
}

const ALLOWED_TYPES = ["image/jpeg", "image/png", "image/webp"];
const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB

export function ImageUpload({ onUpload, maxSize = 5, accept = "image/*" }: ImageUploadProps) {
  const [preview, setPreview] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const validateFile = (file: File): string | null => {
    // Validar tipo
    if (!ALLOWED_TYPES.includes(file.type)) {
      return "Apenas JPG, PNG e WebP são permitidos";
    }

    // Validar tamanho
    if (file.size > MAX_FILE_SIZE) {
      return `Arquivo muito grande. Máximo ${maxSize}MB`;
    }

    return null;
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setError(null);
    setIsLoading(true);

    // Validar arquivo
    const validationError = validateFile(file);
    if (validationError) {
      setError(validationError);
      setIsLoading(false);
      return;
    }

    try {
      // Criar preview
      const reader = new FileReader();
      reader.onload = (event) => {
        const previewUrl = event.target?.result as string;
        setPreview(previewUrl);
        onUpload(file, previewUrl);
        setIsLoading(false);
      };
      reader.readAsDataURL(file);
    } catch (err) {
      setError("Erro ao processar imagem");
      setIsLoading(false);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file && fileInputRef.current) {
      const dataTransfer = new DataTransfer();
      dataTransfer.items.add(file);
      fileInputRef.current.files = dataTransfer.files;
      handleFileSelect({ target: fileInputRef.current } as any);
    }
  };

  const handleClear = () => {
    setPreview(null);
    setError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  return (
    <div className="space-y-4">
      <div
        onDrop={handleDrop}
        onDragOver={(e) => e.preventDefault()}
        className="border-2 border-dashed border-border rounded-lg p-8 text-center hover:border-primary/50 transition cursor-pointer"
        onClick={() => fileInputRef.current?.click()}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept={accept}
          onChange={handleFileSelect}
          className="hidden"
        />

        {preview ? (
          <div className="space-y-2">
            <img
              src={preview}
              alt="Preview"
              className="w-full max-h-64 object-cover rounded-lg mx-auto"
            />
            <p className="text-sm text-muted-foreground">Clique para alterar</p>
          </div>
        ) : (
          <div className="space-y-2">
            <Upload className="w-12 h-12 mx-auto text-muted-foreground" />
            <p className="text-foreground font-medium">Arraste a imagem aqui</p>
            <p className="text-sm text-muted-foreground">ou clique para selecionar</p>
            <p className="text-xs text-muted-foreground">
              JPG, PNG ou WebP até {maxSize}MB
            </p>
          </div>
        )}
      </div>

      {error && (
        <div className="flex gap-2 p-3 bg-red-50 border border-red-200 rounded-lg">
          <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
          <p className="text-sm text-red-600">{error}</p>
        </div>
      )}

      {preview && (
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handleClear}
            className="flex-1 gap-2"
          >
            <X className="w-4 h-4" />
            Remover
          </Button>
          <Button
            size="sm"
            className="flex-1 gap-2 bg-green-600 hover:bg-green-700"
            disabled={isLoading}
          >
            <Check className="w-4 h-4" />
            {isLoading ? "Processando..." : "Confirmar"}
          </Button>
        </div>
      )}
    </div>
  );
}
