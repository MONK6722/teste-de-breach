import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Share2, Copy, Check, X } from "lucide-react";

interface ShareEventProps {
  eventTitle: string;
  eventSlug: string;
  eventDescription?: string;
}

export function ShareEvent({ eventTitle, eventSlug, eventDescription }: ShareEventProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  const eventUrl = `${window.location.origin}/event/${eventSlug}`;
  const shareText = `Confira este evento: ${eventTitle}`;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(eventUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShareWhatsApp = () => {
    const message = encodeURIComponent(`${shareText}\n${eventUrl}`);
    window.open(`https://wa.me/?text=${message}`, "_blank");
  };

  const handleShareFacebook = () => {
    window.open(
      `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(eventUrl)}`,
      "_blank"
    );
  };

  const handleShareInstagram = () => {
    // Instagram não tem share direto, então copiamos o link
    handleCopyLink();
    alert("Link copiado! Cole nos seus stories ou direct do Instagram.");
  };

  return (
    <div className="relative">
      <Button
        variant="outline"
        size="sm"
        onClick={() => setIsOpen(!isOpen)}
        className="gap-2"
      >
        <Share2 className="w-4 h-4" />
        Compartilhar
      </Button>

      {isOpen && (
        <div className="absolute top-full right-0 mt-2 z-50">
          <Card className="card-elegant p-4 w-64">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-semibold text-foreground">Compartilhar Evento</h3>
              <button
                onClick={() => setIsOpen(false)}
                className="text-muted-foreground hover:text-foreground"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2">
              <Button
                variant="outline"
                size="sm"
                className="w-full justify-start gap-2 text-green-600 hover:text-green-700"
                onClick={handleShareWhatsApp}
              >
                <span>💬</span>
                WhatsApp
              </Button>

              <Button
                variant="outline"
                size="sm"
                className="w-full justify-start gap-2 text-blue-600 hover:text-blue-700"
                onClick={handleShareFacebook}
              >
                <span>f</span>
                Facebook
              </Button>

              <Button
                variant="outline"
                size="sm"
                className="w-full justify-start gap-2 text-pink-600 hover:text-pink-700"
                onClick={handleShareInstagram}
              >
                <span>📷</span>
                Instagram
              </Button>

              <div className="border-t border-border pt-2 mt-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full justify-start gap-2"
                  onClick={handleCopyLink}
                >
                  {copied ? (
                    <>
                      <Check className="w-4 h-4 text-green-600" />
                      Copiado!
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4" />
                      Copiar Link
                    </>
                  )}
                </Button>
              </div>
            </div>

            <div className="mt-3 p-2 bg-accent/10 rounded text-xs text-muted-foreground">
              Link: {eventUrl.substring(0, 30)}...
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}
