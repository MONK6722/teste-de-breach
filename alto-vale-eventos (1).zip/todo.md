# Alto Vale Eventos - TODO COMPLETO

## FASE 1: Login e Autenticação
- [x] Criar página de login específica para criadores
- [ ] Criar página de login específica para validadores
- [ ] Criar página de login específica para administradores
- [ ] Implementar verificação de email corporativo (ilab.corporation.oficial@gmail.com)
- [ ] Criar dashboard após login com opções específicas por role
- [ ] Implementar logout e gerenciamento de sessão

## FASE 2: Upload de Fotos
- [x] Implementar upload de foto de capa do evento
- [x] Implementar upload de carrossel de fotos (múltiplas)
- [x] Integrar com CDN para armazenamento
- [x] Validar tipos de arquivo (jpg, png, webp)
- [x] Validar tamanho máximo de arquivo
- [x] Exibir preview das fotos antes de salvar
- [x] Implementar cropping/redimensionamento

## FASE 3: Validação por Categoria
- [x] Criar interface de validação por categoria
- [x] Cada validador vê apenas eventos de sua categoria
- [ ] Implementar selos de verificação visuais
- [x] Mostrar status de validação (pendente, aprovado, rejeitado)
- [x] Adicionar motivo de rejeição
- [ ] Histórico de validações

## FASE 4: Checkout Completo
- [x] Criar página de checkout elegante
- [x] Exibir taxa por ingresso (R$3-4) de forma clara
- [x] Exibir breakdown: preço ingresso + taxa + total
- [x] Implementar seleção de quantidade de ingressos
- [ ] Implementar seleção de tipo de ingresso
- [ ] Integração com Stripe (ou gateway de pagamento)
- [ ] Confirmação de compra por email

## FASE 5: Ingressos Gratuitos
- [x] Permitir criador definir ingressos como gratuitos
- [x] Implementar reserva de ingresso gratuito
- [x] Gerar QR code para ingresso gratuito
- [ ] Sistema de check-in/validação de presença
- [x] Controle de capacidade para ingressos gratuitos
- [ ] Relatório de presença

## FASE 6: Compartilhamento
- [x] Botão de compartilhar no WhatsApp
- [x] Botão de compartilhar no Facebook
- [x] Botão de compartilhar no Instagram
- [x] Botão de copiar link
- [x] Gerar preview bonito para compartilhamento
- [ ] Rastreamento de compartilhamentos

## FASE 7: Avaliações
- [ ] Criar formulário de avaliação do site
- [ ] Criar sistema de avaliação de eventos (1-5 estrelas)
- [ ] Permitir comentários nas avaliações
- [ ] Exibir média de avaliações
- [ ] Moderar avaliações (admin)
- [ ] Mostrar avaliações na página do evento

## FASE 8: Filtros Avançados
- [ ] Filtro por data (data inicial e final)
- [ ] Filtro por horário (manhã, tarde, noite)
- [ ] Filtro por capacidade disponível
- [ ] Filtro por tipo de ingresso (pago/gratuito)
- [ ] Filtro por status de validação
- [ ] Ordenação por data, popularidade, avaliação

## FASE 9: Email Corporativo
- [ ] Configurar email: ilab.corporation.oficial@gmail.com
- [ ] Criar template de email de confirmação de compra
- [ ] Criar template de email de novo evento
- [ ] Criar template de email de validação
- [ ] Criar template de email de rejeição
- [ ] Sistema de notificações por email

## FASE 10: Testes Completos
- [ ] Testar fluxo completo de criação de evento
- [ ] Testar fluxo completo de compra de ingresso
- [ ] Testar fluxo completo de validação
- [ ] Testar responsividade em iPhone 6/7/8
- [ ] Testar responsividade em iPhone 12/13
- [ ] Testar responsividade em Android
- [ ] Testar em Chrome, Firefox, Safari
- [ ] Testar velocidade de carregamento
- [ ] Testar acessibilidade
- [ ] Testar segurança (XSS, CSRF, SQL Injection)

## FASE 11: Funcionalidades Extras
- [ ] Criar página "Sobre" com informações da plataforma
- [ ] Criar página de FAQ
- [ ] Criar página de Termos de Serviço
- [ ] Criar página de Privacidade
- [ ] Link para Instagram (badge/link)
- [ ] Criar nome do site (sugestão: "Venha Aqui" ou similar)
- [ ] Criar logo profissional
- [ ] Implementar analytics (Google Analytics)

## FASE 12: Dados de Exemplo
- [ ] Criar 5-10 eventos de exemplo para teste
- [ ] Criar usuários de teste (criador, validador, admin)
- [ ] Criar tickets/ingressos de exemplo
- [ ] Criar avaliações de exemplo

## FASE 13: Deploy e Documentação
- [ ] Criar documentação de uso para criadores
- [ ] Criar documentação de uso para validadores
- [ ] Criar documentação de uso para admin
- [ ] Preparar para deploy
- [ ] Testar em produção
- [ ] Criar guia de suporte
