import mysql from 'mysql2/promise';
import * as fs from 'fs';

async function runMigrations() {
  try {
    const conn = await mysql.createConnection(process.env.DATABASE_URL);
    const sql = fs.readFileSync('./drizzle/0001_remarkable_boomer.sql', 'utf-8');
    const statements = sql.split('--> statement-breakpoint').filter(s => s.trim());

    console.log('🌱 Executando migrations...');
    for (const stmt of statements) {
      const trimmed = stmt.trim();
      if (!trimmed) continue;
      
      try {
        await conn.execute(trimmed);
        console.log('✅ Executado:', trimmed.substring(0, 60) + '...');
      } catch (e) {
        if (e.code === 'ER_DUP_FIELDNAME') {
          console.log('⏭️  Campo já existe, pulando...');
        } else {
          console.error('❌ Erro:', e.message);
        }
      }
    }

    await conn.end();
    console.log('🎉 Migrations concluídas!');
  } catch (error) {
    console.error('❌ Erro fatal:', error);
    process.exit(1);
  }
}

runMigrations();
